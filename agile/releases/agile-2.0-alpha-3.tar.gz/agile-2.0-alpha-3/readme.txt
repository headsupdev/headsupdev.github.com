HeadsUp Agile
=============

Thank you for downloading HeadsUp Agile.

This file contains a quick start guide to running HeadsUp, more detailed information can be found at:
  http://headsupdev.com/agile/install


Quickstart
----------

* Unpack this archive (which you have probably already done)
* Ensure you have the Sun Java SDK 1.6 or later
* Open a terminal or console and navigate to this directory
* Execute ./bin/agile.sh
* Open a web browser at http://localhost:8069/

Support
-------

Should you have any questions or comments please email us:
  support@headsupdev.com .

Alternatively you can use the contact form available at:
  http://headsupdev.com/contact/

Copyright (C) 2009-2012 Heads Up Development Ltd. All rights reserved.
  http://headsupdev.com/

